
export interface Country {
  name: string;
  code: string;
  dialCode: string;
  flag: string;
}

export interface WhatsAppData {
  countryCode: string;
  phoneNumber: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  message?: string;
}

export interface HistoryItem {
  id: string;
  phoneNumber: string;
  message: string;
  link: string;
  timestamp: number;
}


import React from 'react';
import { COUNTRIES } from '../constants';
import { Country } from '../types';

interface CountrySelectorProps {
  selectedDialCode: string;
  onSelect: (country: Country) => void;
}

const CountrySelector: React.FC<CountrySelectorProps> = ({ selectedDialCode, onSelect }) => {
  return (
    <div className="relative group">
      <select
        value={selectedDialCode}
        onChange={(e) => {
          const country = COUNTRIES.find(c => c.dialCode === e.target.value);
          if (country) onSelect(country);
        }}
        className="block w-full pl-3 pr-10 py-3 text-base border-gray-300 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm rounded-md bg-white border cursor-pointer appearance-none"
      >
        {COUNTRIES.map((c) => (
          <option key={`${c.code}-${c.dialCode}`} value={c.dialCode}>
            {c.flag} +{c.dialCode}
          </option>
        ))}
      </select>
      <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
        <svg className="h-4 w-4 fill-current" viewBox="0 0 20 20">
          <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
        </svg>
      </div>
    </div>
  );
};

export default CountrySelector;


import React from 'react';
import { Bold, Italic, Strikethrough, Type } from 'lucide-react';

interface FormattingToolbarProps {
  onFormat: (prefix: string, suffix: string) => void;
}

const FormattingToolbar: React.FC<FormattingToolbarProps> = ({ onFormat }) => {
  const tools = [
    { icon: <Bold size={16} />, label: 'Bold', prefix: '*', suffix: '*' },
    { icon: <Italic size={16} />, label: 'Italic', prefix: '_', suffix: '_' },
    { icon: <Strikethrough size={16} />, label: 'Strike', prefix: '~', suffix: '~' },
    { icon: <Type size={16} />, label: 'Mono', prefix: '```', suffix: '```' },
  ];

  return (
    <div className="flex items-center gap-1 p-1 bg-slate-50 border-b border-gray-200">
      {tools.map((tool) => (
        <button
          key={tool.label}
          type="button"
          onClick={() => onFormat(tool.prefix, tool.suffix)}
          className="p-2 hover:bg-white hover:shadow-sm rounded text-slate-600 hover:text-green-600 transition-all flex items-center justify-center"
          title={tool.label}
        >
          {tool.icon}
        </button>
      ))}
    </div>
  );
};

export default FormattingToolbar;

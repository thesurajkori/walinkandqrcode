
import React from 'react';
import { Copy, Download, CheckCircle2, Share2 } from 'lucide-react';

interface ActionButtonsProps {
  link: string;
  onDownloadPNG: () => void;
  onDownloadSVG: () => void;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({ link, onDownloadPNG, onDownloadSVG }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-6">
      <button
        onClick={handleCopy}
        className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-medium transition-all ${
          copied 
            ? 'bg-green-600 text-white' 
            : 'bg-white text-gray-700 border border-gray-300 hover:border-green-500 hover:text-green-600 shadow-sm'
        }`}
      >
        {copied ? (
          <>
            <CheckCircle2 size={18} />
            <span>Link Copied!</span>
          </>
        ) : (
          <>
            <Copy size={18} />
            <span>Copy Link</span>
          </>
        )}
      </button>

      <div className="flex gap-2">
        <button
          onClick={onDownloadPNG}
          className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 shadow-md transition-all active:scale-95"
        >
          <Download size={18} />
          <span>PNG</span>
        </button>
        <button
          onClick={onDownloadSVG}
          className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gray-800 text-white rounded-lg font-medium hover:bg-gray-900 shadow-md transition-all active:scale-95"
        >
          <Share2 size={18} />
          <span>SVG</span>
        </button>
      </div>
    </div>
  );
};

export default ActionButtons;


import React, { useState, useEffect, useRef, useCallback } from 'react';
import { QRCodeSVG, QRCodeCanvas } from 'qrcode.react';
import { 
  MessageSquare, Phone, Info, Smartphone, QrCode, 
  History, Sparkles, Trash2, Moon, Sun, Send, Share2
} from 'lucide-react';
import CountrySelector from './components/CountrySelector';
import EmojiPicker from './components/EmojiPicker';
import ActionButtons from './components/ActionButtons';
import FormattingToolbar from './components/FormattingToolbar';
import { COUNTRIES } from './constants';
import { WhatsAppData, ValidationResult, HistoryItem } from './types';

const TEMPLATES = [
  { label: '👋 Greeting', text: 'Hello! I would like to know more about your services.' },
  { label: '💰 Pricing', text: 'Hi, can you please share your price list?' },
  { label: '📅 Booking', text: 'I would like to schedule an appointment for next week.' },
  { label: '🛠 Support', text: 'Hi, I need help with my recent order.' }
];

const App: React.FC = () => {
  const [data, setData] = useState<WhatsAppData>({
    countryCode: COUNTRIES.find(c => c.code === 'US')?.dialCode || '1',
    phoneNumber: '',
    message: '',
  });

  const [validation, setValidation] = useState<ValidationResult>({ isValid: true });
  const [generatedLink, setGeneratedLink] = useState('');
  const [isGenerated, setIsGenerated] = useState(false);
  const [isPreviewDarkMode, setIsPreviewDarkMode] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  
  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  // Load History
  useEffect(() => {
    const saved = localStorage.getItem('qr_history');
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  // Save History
  const saveToHistory = (link: string) => {
    const newItem: HistoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      phoneNumber: `+${data.countryCode}${data.phoneNumber}`,
      message: data.message,
      link,
      timestamp: Date.now()
    };
    const updated = [newItem, ...history].slice(0, 5);
    setHistory(updated);
    localStorage.setItem('qr_history', JSON.stringify(updated));
  };

  const handleFormat = (prefix: string, suffix: string) => {
    const el = textAreaRef.current;
    if (!el) return;
    const start = el.selectionStart;
    const end = el.selectionEnd;
    const text = el.value;
    const before = text.substring(0, start);
    const selection = text.substring(start, end);
    const after = text.substring(end);
    
    const newMessage = before + prefix + selection + suffix + after;
    setData({ ...data, message: newMessage });
    
    // Focus back and set selection
    setTimeout(() => {
      el.focus();
      el.setSelectionRange(start + prefix.length, end + prefix.length);
    }, 10);
  };

  const validateAndGenerate = () => {
    const cleanNumber = data.phoneNumber.replace(/\D/g, '');
    if (!cleanNumber || cleanNumber.length < 7) {
      setValidation({ isValid: false, message: 'Please enter a valid phone number.' });
      setIsGenerated(false);
      return;
    }

    setValidation({ isValid: true });
    const fullNumber = `${data.countryCode}${cleanNumber}`;
    const encodedMessage = encodeURIComponent(data.message);
    const link = `https://wa.me/${fullNumber}${data.message ? `?text=${encodedMessage}` : ''}`;
    
    setGeneratedLink(link);
    setIsGenerated(true);
    saveToHistory(link);
  };

  // Helper to render formatted text in preview
  // Fixed "Cannot find namespace 'JSX'" by adding explicit React.ReactNode return type
  const formatWhatsAppText = (text: string): React.ReactNode => {
    if (!text) return <span className="text-slate-400 italic">No message preview...</span>;
    
    // Fixed "Cannot find namespace 'JSX'" by replacing JSX.Element with React.ReactNode
    let parts: (string | React.ReactNode)[] = [text];

    // Simple parser for WhatsApp markdown
    // Fixed "Cannot find namespace 'JSX'" by replacing JSX.Element with React.ReactNode
    const parse = (str: string, regex: RegExp, component: (s: string) => React.ReactNode) => {
      // Fixed "Cannot find namespace 'JSX'" by replacing JSX.Element with React.ReactNode
      const newParts: (string | React.ReactNode)[] = [];
      str.split(regex).forEach((part, i) => {
        if (i % 2 === 1) newParts.push(component(part));
        else newParts.push(part);
      });
      return newParts;
    };

    // Apply Bold
    let content = text;
    return text.split(/(\*[^*]+\*)/g).map((part, i) => {
      if (part.startsWith('*') && part.endsWith('*')) {
        return <strong key={i}>{part.slice(1, -1)}</strong>;
      }
      return part.split(/(_[^_]+_)/g).map((subPart, j) => {
        if (subPart.startsWith('_') && subPart.endsWith('_')) {
          return <em key={j}>{subPart.slice(1, -1)}</em>;
        }
        return subPart.split(/(~[^~]+~)/g).map((finalPart, k) => {
          if (finalPart.startsWith('~') && finalPart.endsWith('~')) {
            return <del key={k}>{finalPart.slice(1, -1)}</del>;
          }
          if (finalPart.startsWith('```') && finalPart.endsWith('```')) {
            return <code key={k} className="bg-black/10 px-1 rounded">{finalPart.slice(3, -3)}</code>;
          }
          return finalPart;
        });
      });
    });
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('qr_history');
  };

  const handleDownloadPNG = () => {
    const canvas = document.querySelector('canvas');
    if (canvas) {
      const url = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = url;
      link.download = `whatsapp-qr-${data.phoneNumber || 'link'}.png`;
      link.click();
    }
  };

  const handleDownloadSVG = () => {
    const svg = document.querySelector('#qr-svg-target svg');
    if (svg) {
      const svgData = new XMLSerializer().serializeToString(svg);
      const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(svgBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `whatsapp-qr-${data.phoneNumber || 'link'}.svg`;
      link.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="min-h-screen bg-[#f0f2f5] flex flex-col items-center py-6 px-4">
      {/* Navbar Style Header */}
      <nav className="w-full max-w-6xl flex justify-between items-center mb-8 px-4">
        <div className="flex items-center gap-2">
          <div className="bg-green-600 p-2 rounded-lg text-white">
            <QrCode size={24} />
          </div>
          <span className="text-xl font-bold text-slate-800 tracking-tight">WA<span className="text-green-600">Quick</span></span>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setIsPreviewDarkMode(!isPreviewDarkMode)} className="p-2 text-slate-500 hover:bg-white rounded-full transition-all shadow-sm">
            {isPreviewDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </nav>

      <main className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-6 mb-12">
        {/* Left: Input Panel */}
        <section className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-700 font-bold">1</div>
              <h2 className="text-xl font-bold text-slate-800">Configure Chat</h2>
            </div>

            <div className="space-y-6">
              {/* Phone Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1 ml-1">Country</label>
                  <CountrySelector 
                    selectedDialCode={data.countryCode} 
                    onSelect={(c) => setData(prev => ({ ...prev, countryCode: c.dialCode }))}
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1 ml-1">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="Enter phone number"
                    value={data.phoneNumber}
                    onChange={(e) => setData(prev => ({ ...prev, phoneNumber: e.target.value.replace(/\D/g, '') }))}
                    className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:bg-white transition-all outline-none"
                  />
                </div>
              </div>

              {!validation.isValid && (
                <div className="text-red-500 text-xs flex items-center gap-1.5 px-3 py-2 bg-red-50 rounded-lg border border-red-100">
                  <Info size={14} /> {validation.message}
                </div>
              )}

              {/* Message with Toolbar */}
              <div>
                <div className="flex items-center justify-between mb-1 ml-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Custom Message</label>
                  <EmojiPicker onEmojiSelect={(emoji) => setData(prev => ({ ...prev, message: prev.message + emoji }))} />
                </div>
                <div className="border border-slate-200 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-green-500 transition-all bg-white">
                  <FormattingToolbar onFormat={handleFormat} />
                  <textarea
                    ref={textAreaRef}
                    rows={4}
                    placeholder="Write your message here... use buttons above to style it!"
                    value={data.message}
                    onChange={(e) => setData(prev => ({ ...prev, message: e.target.value }))}
                    className="block w-full px-4 py-3 bg-white outline-none resize-none text-slate-700"
                  />
                </div>
              </div>

              {/* Templates Section */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1 flex items-center gap-1.5">
                  <Sparkles size={14} className="text-amber-500" /> Quick Templates
                </label>
                <div className="flex flex-wrap gap-2">
                  {TEMPLATES.map((t) => (
                    <button
                      key={t.label}
                      onClick={() => setData(prev => ({ ...prev, message: t.text }))}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-green-100 hover:text-green-700 rounded-full text-xs font-medium text-slate-600 transition-all border border-transparent hover:border-green-200"
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={validateAndGenerate}
                className="w-full bg-green-600 text-white font-bold py-4 rounded-xl hover:bg-green-700 shadow-lg shadow-green-100 transition-all flex items-center justify-center gap-2 group active:scale-[0.98]"
              >
                <QrCode size={20} className="group-hover:rotate-12 transition-transform" />
                Generate QR Code & Link
              </button>
            </div>
          </div>

          {/* History Panel */}
          {history.length > 0 && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-slate-800 font-bold">
                  <History size={18} className="text-slate-400" />
                  Recent Generations
                </div>
                <button onClick={clearHistory} className="text-xs text-red-500 hover:underline flex items-center gap-1">
                  <Trash2 size={12} /> Clear
                </button>
              </div>
              <div className="space-y-3">
                {history.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl group hover:bg-green-50 transition-all border border-transparent hover:border-green-100">
                    <div className="overflow-hidden mr-4">
                      <div className="text-sm font-bold text-slate-700">{item.phoneNumber}</div>
                      <div className="text-xs text-slate-400 truncate">{item.message || '(No message)'}</div>
                    </div>
                    <button 
                      onClick={() => {
                        setGeneratedLink(item.link);
                        setIsGenerated(true);
                      }}
                      className="p-2 bg-white text-green-600 rounded-lg shadow-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-green-600 hover:text-white"
                    >
                      <Send size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>

        {/* Right: Preview Panel */}
        <section className="lg:col-span-5 flex flex-col gap-6">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden sticky top-6">
            <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-700">
                <Smartphone size={18} className="text-slate-400" />
                Chat Preview
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-[10px] uppercase font-bold text-slate-400">Live</span>
              </div>
            </div>

            <div className="p-8 flex flex-col items-center">
              {/* Modern Phone Bezel */}
              <div className={`w-[280px] h-[540px] rounded-[3rem] border-[8px] border-slate-900 shadow-2xl relative overflow-hidden transition-colors ${isPreviewDarkMode ? 'bg-slate-900' : 'bg-slate-50'}`}>
                {/* Dynamic Island */}
                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-24 h-6 bg-slate-900 rounded-full z-20 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-800" />
                </div>
                
                {/* Screen Content */}
                <div className={`h-full flex flex-col ${isPreviewDarkMode ? 'bg-[#0b141a]' : 'bg-[#e5ddd5]'}`}>
                  {/* WhatsApp Header */}
                  <div className={`p-4 pt-10 flex items-center gap-3 shadow-md z-10 ${isPreviewDarkMode ? 'bg-[#202c33] text-white' : 'bg-[#075e54] text-white'}`}>
                    <div className="w-9 h-9 rounded-full bg-slate-300 overflow-hidden">
                      <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${data.phoneNumber || 'User'}`} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold truncate">+{data.countryCode} {data.phoneNumber || 'Number'}</div>
                      <div className="text-[10px] opacity-70">Online</div>
                    </div>
                  </div>

                  {/* Message Area */}
                  <div className="flex-1 p-4 flex flex-col justify-end gap-2 overflow-y-auto">
                    <div className="self-center bg-black/5 text-[9px] px-2 py-1 rounded mb-4 uppercase tracking-wider font-bold">Today</div>
                    
                    <div className={`self-end max-w-[85%] p-3 rounded-lg rounded-tr-none shadow-sm relative group ${isPreviewDarkMode ? 'bg-[#005c4b] text-[#e9edef]' : 'bg-[#dcf8c6] text-[#111b21]'}`}>
                      <div className="text-[11px] leading-relaxed whitespace-pre-wrap mb-1">
                        {formatWhatsAppText(data.message)}
                      </div>
                      <div className="text-[9px] text-right opacity-60 flex items-center justify-end gap-1">
                        12:45 PM
                        <svg className="w-3 h-3 text-blue-400" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z"/></svg>
                      </div>
                    </div>
                  </div>

                  {/* Message Input Frame */}
                  <div className={`p-2 flex items-center gap-2 ${isPreviewDarkMode ? 'bg-[#202c33]' : 'bg-[#f0f2f5]'}`}>
                    <div className={`flex-1 rounded-full h-9 px-4 flex items-center text-xs ${isPreviewDarkMode ? 'bg-[#2a3942] text-[#8696a0]' : 'bg-white text-slate-400'}`}>
                      Type a message
                    </div>
                    <div className="w-9 h-9 bg-green-500 rounded-full flex items-center justify-center text-white shadow-sm">
                      <Send size={16} />
                    </div>
                  </div>
                </div>
              </div>

              {/* QR and Actions Area */}
              <div className="w-full mt-10 space-y-4">
                <div className="flex flex-col items-center bg-slate-50 rounded-2xl p-6 border-2 border-dashed border-slate-200">
                  <div className="bg-white p-4 rounded-2xl shadow-xl mb-4 transform hover:scale-105 transition-transform duration-300 border border-slate-100">
                    <QRCodeCanvas
                      value={generatedLink || 'https://wa.me/'}
                      size={180}
                      level="H"
                      includeMargin={false}
                      imageSettings={{
                        src: "https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg",
                        x: undefined,
                        y: undefined,
                        height: 38,
                        width: 38,
                        excavate: true,
                      }}
                    />
                  </div>
                  
                  {/* Hidden SVG for download */}
                  <div className="hidden" id="qr-svg-target">
                    <QRCodeSVG
                      value={generatedLink || 'https://wa.me/'}
                      size={1024}
                      level="H"
                      includeMargin={true}
                    />
                  </div>

                  <div className="text-center">
                    <div className="text-slate-800 font-bold">QR Code Generated</div>
                    <div className="text-[10px] text-slate-400 font-mono mt-1 max-w-[200px] truncate mx-auto bg-slate-200 px-2 py-0.5 rounded">
                      {generatedLink || 'Waiting for input...'}
                    </div>
                  </div>

                  {isGenerated && (
                    <div className="w-full">
                      <ActionButtons 
                        link={generatedLink} 
                        onDownloadPNG={handleDownloadPNG} 
                        onDownloadSVG={handleDownloadSVG}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer / Value Prop */}
      <footer className="w-full max-w-4xl text-center space-y-4 text-slate-500 pb-12">
        <div className="flex flex-wrap justify-center gap-6 text-sm">
          <div className="flex items-center gap-1.5"><Info size={14} /> 100% Free</div>
          <div className="flex items-center gap-1.5"><Sparkles size={14} /> High Quality SVG</div>
          <div className="flex items-center gap-1.5"><Phone size={14} /> Business Ready</div>
        </div>
        <p className="text-xs">
          Built for privacy. We never store your phone numbers. All generation happens in your browser.
        </p>
      </footer>
    </div>
  );
};

export default App;
